package contract.util;

/**
 * Computing tool class
 *
 * @author captain
 * @version 1.0
 * @date 19-1-31 下午12:50
 */
public class Math {

    public static int min(int a, int b) {
        return a<b ? a : b;
    }
}
